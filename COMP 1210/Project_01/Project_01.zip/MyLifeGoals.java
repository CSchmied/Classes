/**
* Simple program to print out my life goals.
*
* Project 1
* @author Carlton Schmieder
* @version 1-15-18
*/
public class MyLifeGoals
{
/**
* First line prints my first and last name.
* Then prints my short, medium, and long term goals.
* @param args Command line arguments.
*/ 
   public static void main(String[] args)
   {
      System.out.println("Carlton Schmieder");
      System.out.println("");
      System.out.println("My short term is to pass this class with an A. "
         + "I also want to finish this semester with a 4.0 so that "
         + "I can improve my GPA to a 3.85.");
      System.out.println("My medium term goal is to be physically "
         + "fit. I also want to be able to graduate Auburn in four years. "
          + "Then possibly persue a masters degree.");
      System.out.println("My long term goal is to find a successful job " 
         + "in Cybersecurity to provide for my family. I also want to put my "
            + "children through college debt free.");
   }
}
