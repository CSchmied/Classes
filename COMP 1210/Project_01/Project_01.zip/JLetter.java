/**
* Program to print out the letter J with "Java".
*
* Project 1
* @author Carlton Schmieder
* @version 1-15-18
*/ 
public class JLetter
{
/**
* Print the letter J using Java in 10 lines.
* @param args Command line arguments - not used 
*/
   public static void main(String[] args)
   {
      System.out.println("JAVAJAVAJAVA");
      System.out.println("JAVAJAVAJAVA");
      System.out.println("      JAVA");
      System.out.println("      JAVA");
      System.out.println("      JAVA");
      System.out.println("      JAVA");
      System.out.println("J     JAVA");
      System.out.println("JA    JAVA");
      System.out.println(" JAVAJAVA");
      System.out.println("  JAVAJA");
   }
}