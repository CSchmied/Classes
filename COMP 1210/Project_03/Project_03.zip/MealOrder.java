import java.util.Scanner;
import java.text.DecimalFormat;
/** 
*Program to take the order code and print out the number of adult
meals and number of child meals. Then if it is over $100, it adds
in the 15% discount and prints name, meals, subtotal, discount, total and 
lucky number. If it is under $100 it prints out name, meals, 
total, and lucky number.
*
* Project_03
* @author - Carlton Schmieder
* @version 2-1-19
*/ 
public class MealOrder
{
   static final double DISCOUNT = 0.15;
   
   static final double DISCOUNT_THRESHOLD = 100.0;
   /** 
   * String where I put all the variables and equations to generate
   the total etc. 
   *
   * @param args Command line arguments - not used 
   */ 
   public static void main(String[] args) 
   { 
      Scanner userInput = new Scanner(System.in); 
      String order = "";
      int luckynum = 0;  
      DecimalFormat df = new DecimalFormat("$#,##0.00");
      DecimalFormat df2 = new DecimalFormat("00000");
      //Where to insert the order number.  
      System.out.print("Enter your order code:    "); 
      order = userInput.nextLine().trim();
      if (order.length() >= 12) {
         System.out.println();
         order = order.trim(); 
         char ordername = order.charAt(0); 
         //Number of adult meals.
         int numadultmeal = Integer.parseInt(order.substring(0, 2)); 
         //Price per adult meals.
         double priceadultmeal = Double.parseDouble(order.substring(2, 6)) 
            / 100;
         //Number of child meals.
         int numchildmeal = Integer.parseInt(order.substring(6, 8)); 
         //Price per child meals.
         double pricechildmeal = Double.parseDouble(order.substring(8, 12)) 
            / 100;
         String name = order.substring(12);
         //Equation to find the total cost.
         double total = ((int) numadultmeal * (double) priceadultmeal) 
            + ((int) numchildmeal * (double) pricechildmeal);
         //If total is under $100, the program prints the total cost etc.
         if (total <= DISCOUNT_THRESHOLD) {
            System.out.println("Name: " + name);
            System.out.println("Adult meals: " + numadultmeal + " at " 
               + df.format(priceadultmeal)); 
            System.out.println("Child meals: " + numchildmeal + " at " 
               + df.format(pricechildmeal)); 
            System.out.println("Total: " + df.format(total));
            luckynum = (int) (Math.random() * 99999) + 1;
            System.out.println("Lucky Number: " + df2.format(luckynum));
         }
         // If total is over $100, the program prints the discount 
         //and calculates the total etc.
         else {
            System.out.println("Name: " + name);
            System.out.println("Adult meals: " + numadultmeal + " at " 
               + df.format(priceadultmeal)); 
            System.out.println("Child meals: " + numchildmeal + " at " 
               + df.format(pricechildmeal));
            System.out.println("Subtotal: " + df.format(total)); 
            double reduce = total * -DISCOUNT;
            System.out.println("15% Discount: " + df.format(reduce));
            double afterdiscount = total + reduce; 
            System.out.println("Total: " + df.format(afterdiscount));
            luckynum = (int) (Math.random() * 99999) + 1; 
            System.out.println("Lucky Number: " + df2.format(luckynum)); 
         }
      }
      // If code is not correct, the program prints this
      else {
         System.out.println("");
         System.out.println("Invalid Order Code.");
         System.out.println("Order code must have at least 12 characters.");
      }
       
         
      
   }
}